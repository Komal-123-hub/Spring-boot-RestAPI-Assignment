package com.xyzInsurance.brokerOnboardingSvc.services;

import java.util.List;
import com.xyzInsurance.brokerOnboardingSvc.entities.InsuranceBroker;

public interface InsuranceBrokerService {
	List<InsuranceBroker> getAllInsuranceBrokers();
	int addInsuranceBroker(InsuranceBroker ib);
	List<InsuranceBroker> getInsuranceBroker(Long brokerId);
	int updateBrokerDetails(InsuranceBroker ib,Long brokerId);
	int deleteBroker(Long brokerId);
}
