package com.xyzInsurance.brokerOnboardingSvc.controller;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
//import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;
//import org.springframework.web.server.ResponseStatusException;
import com.xyzInsurance.brokerOnboardingSvc.entities.InsuranceBroker;
import com.xyzInsurance.brokerOnboardingSvc.services.InsuranceBrokerService;
@RestController
public class MyController {
	@Autowired
	private InsuranceBrokerService insuranceBrokerService;
	
	@GetMapping("/allbrokers")
	public ResponseEntity<List<InsuranceBroker>> getAllInsuranceBrokers(//@RequestHeader(value="Accept") String acceptHeader,
			@RequestHeader(value="Authorization") String authorizationHeader)
	{
		if(authorizationHeader.equals("Bearer authToken"))
		{
			List<InsuranceBroker> brokerList=insuranceBrokerService.getAllInsuranceBrokers();
			if(brokerList.size()<=0)
				return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
			return ResponseEntity.of(Optional.of(brokerList));
		}
		else {
			return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
		}
	}
	
	@GetMapping("/broker/{brokerId}")
	public ResponseEntity<List<InsuranceBroker>> getInsuranceBroker(//@RequestHeader(value="Accept") String acceptHeader,
			@RequestHeader(value="Authorization") String authorizationHeader,
			@PathVariable String brokerId)
	{
		if(authorizationHeader.equals("Bearer authToken"))
		{
			List<InsuranceBroker> brokerList=insuranceBrokerService.getInsuranceBroker(Long.parseLong(brokerId));
			if(brokerList.size()<=0)
				return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
			return ResponseEntity.of(Optional.of(brokerList));
		}
		else {
			return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
		}
	}
	
	
	
	@PostMapping("/broker/save")
	public ResponseEntity<InsuranceBroker> addInsuranceBroker(//@RequestHeader(value="Accept") String acceptHeader,
			@RequestHeader(value="Authorization") String authorizationHeader,
			@RequestBody InsuranceBroker ib)
	{
	
		if(authorizationHeader.equals("Bearer authToken"))
		{
			int checkAndPost= insuranceBrokerService.addInsuranceBroker(ib);
			System.out.println(checkAndPost);
			if(checkAndPost > 0)
				return ResponseEntity.status(HttpStatus.CREATED).body(ib);
			
			else
				return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE).build();
		}
		
		else {
			return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
		}
	}
	
	@PutMapping("/broker/{brokerId}")
	public ResponseEntity<InsuranceBroker> updateBrokerRecord(//@RequestHeader(value="Accept") String acceptHeader,
			@RequestHeader(value="Authorization") String authorizationHeader,
			@RequestBody InsuranceBroker ib,@PathVariable String brokerId)
	{
		if(authorizationHeader.equals("Bearer authToken"))
		{
			int checkAndUpdate = insuranceBrokerService.updateBrokerDetails(ib,Long.parseLong(brokerId));
			if(checkAndUpdate>0)
			return ResponseEntity.status(HttpStatus.OK).body(ib);
			else 
				return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE).build();
		}
		else {
			return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
		}
		
	}
	
	@DeleteMapping("/broker/delete/{brokerId}")
	public ResponseEntity<String> deleteBroker(//@RequestHeader(value="Accept") String acceptHeader,
			@RequestHeader(value="Authorization") String authorizationHeader,
			@PathVariable String brokerId)
	{
	
			if(authorizationHeader.equals("Bearer authToken"))
			{
			
				int checkAndDelete = insuranceBrokerService.deleteBroker(Long.parseLong(brokerId));
				if(checkAndDelete > 0)
				return new ResponseEntity<String>("msg : Record deleted successfully",HttpStatus.OK);
				else
				return new ResponseEntity<String>("msg : Something went wrong. Record was not deleted",HttpStatus.SERVICE_UNAVAILABLE);
			}
			else {
				return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
			}
		}
	}
	
			


