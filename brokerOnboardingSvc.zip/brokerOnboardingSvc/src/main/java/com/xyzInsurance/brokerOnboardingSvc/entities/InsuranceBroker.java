package com.xyzInsurance.brokerOnboardingSvc.entities;

public class InsuranceBroker {
	private Long brokerId;
	private String brokerFirstName;
	private String brokerLastName;
	public InsuranceBroker(Long brokerId, String brokerFirstName, String brokerLastName) {
		super();
		this.brokerId = brokerId;
		this.brokerFirstName = brokerFirstName;
		this.brokerLastName = brokerLastName;
	}
	public InsuranceBroker() {
		super();
		
	}
	public Long getBrokerId() {
		return brokerId;
	}
	public void setBrokerId(Long brokerId) {
		this.brokerId = brokerId;
	}
	public String getFirstName() {
		return brokerFirstName;
	}
	public void setFirstName(String brokerFirstName) {
		this.brokerFirstName = brokerFirstName;
	}
	public String getLastName() {
		return brokerLastName;
	}
	public void setLastName(String brokerLastName) {
		this.brokerLastName = brokerLastName;
	}
	@Override
	public String toString() {
		return "InsuranceBroker [brokerId=" + brokerId + ", firstName=" + brokerFirstName + ", lastName=" + brokerLastName
				+ ", getbrokerId()=" + getBrokerId() + ", getFirstName()=" + getFirstName() + ", getLastName()="
				+ getLastName() + ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()="
				+ super.toString() + "]";
	}
	
}
