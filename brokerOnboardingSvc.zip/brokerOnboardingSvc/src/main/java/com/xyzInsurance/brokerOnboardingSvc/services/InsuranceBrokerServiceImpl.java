package com.xyzInsurance.brokerOnboardingSvc.services;

import java.sql.Connection;  
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.xyzInsurance.brokerOnboardingSvc.entities.InsuranceBroker;
//import com.xyzInsurance.brokerOnboardingSvc.services.InsuranceBrokerService;

@Service
public class InsuranceBrokerServiceImpl implements InsuranceBrokerService {
	
	List<InsuranceBroker> brokerList = new ArrayList<>();
	String databaseURL = "jdbc:ucanaccess://D:/BrokerDetails.accdb;openExclusive=false;ignoreCase=true";
	
	@Override
	public List<InsuranceBroker> getAllInsuranceBrokers(){
		
		try (Connection connection = DriverManager.getConnection(databaseURL)) {
			 String sql = "SELECT * FROM myDatabase";
			 Statement statement = connection.createStatement();
	         ResultSet result = statement.executeQuery(sql);
	         while(result.next()) {
	        	 long brokerId = result.getLong("brokerid");
	        	 String brokerFirstName = result.getString("brokerFirstName");
	        	 String brokerLastName = result.getString("brokerLastName");
	        	 brokerList.add(new InsuranceBroker(brokerId,brokerFirstName,brokerLastName));
	         }
	        	 
	    }catch(SQLException e) {
	    	e.printStackTrace();
	    }         
	    return brokerList;     
	}
	
	@Override
	public List<InsuranceBroker> getInsuranceBroker(Long brokerId) {
		
		try (Connection connection = DriverManager.getConnection(databaseURL)) {
            
            String sql = "SELECT * FROM myDatabase WHERE brokerid = "+brokerId;
             
            Statement statement = connection.createStatement();
            ResultSet result = statement.executeQuery(sql);
            brokerList = new ArrayList<>(); 
            while (result.next()) {
                long brokerid = result.getLong("brokerid");
                String brokerFirstName = result.getString("brokerFirstName");
                String brokerLastName = result.getString("brokerLastName");
                brokerList.add(new InsuranceBroker(brokerid,brokerFirstName,brokerLastName));
            }
             
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
			return brokerList;
	}

	
	@Override
	public int addInsuranceBroker(InsuranceBroker ib) {
		int r=0;
		try (Connection connection = DriverManager.getConnection(databaseURL)) {
            
            
            String sql = "INSERT INTO myDatabase (brokerid, brokerFirstName, brokerLastName) VALUES (?, ?, ?)";
             
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setLong(1, ib.getBrokerId());
            preparedStatement.setString(2, ib.getFirstName());
            preparedStatement.setString(3, ib.getLastName());
             
            r=preparedStatement.executeUpdate();
            
             
        } catch (SQLException ex) {
        	
            ex.printStackTrace();
        }
		return r;
	}
	
	@Override
	public int updateBrokerDetails(InsuranceBroker ib,Long brokerId) {		
		int r=0;
		
		try (Connection connection = DriverManager.getConnection(databaseURL)) {
                       
            String sql = "UPDATE myDatabase SET (brokerid, brokerFirstName, brokerLastName) = (?, ?, ?) WHERE brokerid = ?";
             
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setLong(1, ib.getBrokerId());
            preparedStatement.setString(2, ib.getFirstName());
            preparedStatement.setString(3, ib.getLastName());
            preparedStatement.setLong(4, brokerId);
             
            r = preparedStatement.executeUpdate();
             
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
		return r;
	}
	
	@Override
	public int deleteBroker(Long brokerId) {
		int r=0;
		try (Connection connection = DriverManager.getConnection(databaseURL)) {
            
            String sql = "DELETE FROM myDatabase WHERE brokerid = ?";
            
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setLong(1, brokerId);
            r = preparedStatement.executeUpdate();
            
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
		return r;
	}

}